var content='<div class="ui-page ui-component" deviceName="web" deviceType="desktop" deviceWidth="359" deviceHeight="50">\
    <div id="m-c3a5fa41-70da-4c97-bebb-cfe2956ccbec" class="master growth-vertical devWeb canvas firer ie-background commentable non-processed" alignment="left" name="Footer"width="359" height="50">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/fonts-1732892862020.css" />\
      <div class="freeLayout">\
      <div id="Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.00px" datasizeheight="51.00px" datasizewidthpx="359.9999999999999" datasizeheightpx="50.999999999999886" dataX="0.00" dataY="589.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="Text_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="61.00" dataY="621.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-Text_1_0">Inicio</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="Path_72" class="path firer click commentable non-processed" customid="Home"   datasizewidth="20.00px" datasizeheight="17.00px" dataX="63.00" dataY="603.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="17.0" viewBox="63.0 603.0 20.0 17.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="m-Path_72-c3a5f" d="M71.0 620.0 L71.0 614.0 L75.0 614.0 L75.0 620.0 L80.0 620.0 L80.0 612.0 L83.0 612.0 L73.0 603.0 L63.0 612.0 L66.0 612.0 L66.0 620.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#m-Path_72-c3a5f" fill="#D8F3DC" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="276.00" dataY="621.50" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-Text_3_0">Perfil</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="Path_386" class="path firer commentable non-processed" customid="User"   datasizewidth="16.00px" datasizeheight="16.00px" dataX="280.00" dataY="603.00"  >\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="280.0 603.0 16.0 16.0" preserveAspectRatio="none">\
            	  <g>\
            	    <defs>\
            	      <path id="m-Path_386-c3a5f" d="M288.0 611.0 C290.210000038147 611.0 292.0 609.210000038147 292.0 607.0 C292.0 604.789999961853 290.210000038147 603.0 288.0 603.0 C285.789999961853 603.0 284.0 604.789999961853 284.0 607.0 C284.0 609.210000038147 285.789999961853 611.0 288.0 611.0 Z M288.0 613.0 C285.32999992370605 613.0 280.0 614.3400000333786 280.0 617.0 L280.0 619.0 L296.0 619.0 L296.0 617.0 C296.0 614.3399999141693 290.67000007629395 613.0 288.0 613.0 Z "></path>\
            	    </defs>\
            	    <g style="mix-blend-mode:normal">\
            	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#m-Path_386-c3a5f" fill="#D8F3DC" fill-opacity="1.0"></use>\
            	    </g>\
            	  </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
      </div>\
\
\
      <div id="Group_3" class="group firer ie-background commentable non-processed" customid="Group 3" datasizewidth="0.00px" datasizeheight="0.00px" >\
        <div id="Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Actividades"   datasizewidth="50.00px" datasizeheight="11.00px" dataX="155.50" dataY="622.00" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-Text_2_0">Actividades</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="21.00px" datasizeheight="21.00px" dataX="170.00" dataY="601.50"   alt="image">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
          		<img src="./images/27f23876-c680-4905-a78b-2d7b446306c4.png" />\
          	</div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="60.00px" datasizeheight="36.00px" dataX="151.00" dataY="597.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;