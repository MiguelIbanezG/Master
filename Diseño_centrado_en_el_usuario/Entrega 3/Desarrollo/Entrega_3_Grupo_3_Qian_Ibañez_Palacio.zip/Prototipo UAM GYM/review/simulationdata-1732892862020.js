function initData() {
  jimData.variables["Nombre"] = "";
  jimData.variables["horaSeleccionada"] = "";
  jimData.variables["precio"] = "";
  jimData.variables["Apellido"] = "";
  jimData.datamasters["Actividades"] = [
    {
      "id": 1,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": ""
      }
    },
    {
      "id": 2,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Fútbol"
      }
    },
    {
      "id": 3,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Natación"
      }
    },
    {
      "id": 4,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Tennis"
      }
    },
    {
      "id": 5,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Rugby"
      }
    },
    {
      "id": 6,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Baloncesto"
      }
    },
    {
      "id": 7,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Voleibol"
      }
    },
    {
      "id": 8,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Fútbol sala"
      }
    },
    {
      "id": 9,
      "datamaster": "Actividades",
      "userdata": {
        "41b1c8d9-b1af-43b5-a07a-99ee1efdddeb": "Boxeo"
      }
    }
  ];

  jimData.isInitialized = true;
}