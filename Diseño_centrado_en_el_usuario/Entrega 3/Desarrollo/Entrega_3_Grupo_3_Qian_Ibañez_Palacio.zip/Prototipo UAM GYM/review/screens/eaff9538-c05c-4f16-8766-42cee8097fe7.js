var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-11a5b772-fd90-44b1-a192-02f5b4e781f9" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 2"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/custom-device-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/4175d222-ff93-4208-87a0-713c85ec4c4c/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/4175d222-ff93-4208-87a0-713c85ec4c4c/fonts-1732892862020.css" />\
      <div class="freeLayout">\
      <div id="t-Master_item_3" class="mi-a5c4e233 m-4175d222-ff93-4208-87a0-713c85ec4c4c masterinstance firer ie-background commentable non-processed" master="m-4175d222-ff93-4208-87a0-713c85ec4c4c" customid="HeaderIniciado" datasizewidth="360.00px" datasizeheight="59.00px" dataX="0.00" dataY="0.00" dataAngle="0.0" >\
        <div class="masterInstanceRelativeSizeWrapper">	\
        	<div id="mi-a5c4e233-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="360.00px" datasizeheight="59.00px" datasizewidthpx="360.0" datasizeheightpx="59.0" dataX="0.00" dataY="0.00" >\
        	  <div class="backgroundLayer">\
        	    <div class="colorLayer"></div>\
        	    <div class="imageLayer"></div>\
        	  </div>\
        	  <div class="borderLayer">\
        	    <div class="paddingLayer">\
        	      <div class="content">\
        	        <div class="valign">\
        	          <span id="rtr-mi-a5c4e233-Rectangle_3_0"></span>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
        	<div id="mi-a5c4e233-Image_3" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.00px" datasizeheight="48.33px" dataX="301.00" dataY="5.33"   alt="image">\
        	  <div class="borderLayer">\
        	  	<div class="imageViewport">\
        	  		<img src="./images/e8aec7fd-fdca-4681-bfe0-a7ff6a7b9267.png" />\
        	  	</div>\
        	  </div>\
        	</div>\
\
        </div>\
      </div>\
      <div id="t-Master_item_2" class="mi-2226dae0 m-c3a5fa41-70da-4c97-bebb-cfe2956ccbec masterinstance firer ie-background commentable non-processed" master="m-c3a5fa41-70da-4c97-bebb-cfe2956ccbec" customid="Footer" datasizewidth="360.00px" datasizeheight="51.00px" dataX="0.00" dataY="589.00" dataAngle="0.0" >\
        <div class="masterInstanceRelativeSizeWrapper">	\
        	<div id="mi-2226dae0-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.00px" datasizeheight="51.00px" datasizewidthpx="359.9999999999999" datasizeheightpx="50.999999999999886" dataX="0.00" dataY="0.00" >\
        	  <div class="backgroundLayer">\
        	    <div class="colorLayer"></div>\
        	    <div class="imageLayer"></div>\
        	  </div>\
        	  <div class="borderLayer">\
        	    <div class="paddingLayer">\
        	      <div class="content">\
        	        <div class="valign">\
        	          <span id="rtr-mi-2226dae0-Rectangle_1_0"></span>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
        	<div id="mi-2226dae0-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" dataX="61.00" dataY="14.00" >\
        	  <div id="mi-2226dae0-Text_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="61.00" dataY="32.50" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_1_0">Inicio</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	  <div id="mi-2226dae0-Path_72" class="path firer click commentable non-processed" customid="Home"   datasizewidth="20.00px" datasizeheight="17.00px" dataX="63.00" dataY="14.00"  >\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	      	<?xml version="1.0" encoding="UTF-8"?>\
        	      	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="17.0" viewBox="63.0 603.0 20.0 17.0" preserveAspectRatio="none">\
        	      	  <g>\
        	      	    <defs>\
        	      	      <path id="mi-2226dae0-Path_72-11a5b" d="M71.0 620.0 L71.0 614.0 L75.0 614.0 L75.0 620.0 L80.0 620.0 L80.0 612.0 L83.0 612.0 L73.0 603.0 L63.0 612.0 L66.0 612.0 L66.0 620.0 Z "></path>\
        	      	    </defs>\
        	      	    <g style="mix-blend-mode:normal">\
        	      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-2226dae0-Path_72-11a5b" fill="#D8F3DC" fill-opacity="1.0"></use>\
        	      	    </g>\
        	      	  </g>\
        	      	</svg>\
\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
\
        	<div id="mi-2226dae0-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.00px" datasizeheight="0.00px" dataX="276.00" dataY="14.00" >\
        	  <div id="mi-2226dae0-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="276.00" dataY="32.50" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_3_0">Perfil</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	  <div id="mi-2226dae0-Path_386" class="path firer commentable non-processed" customid="User"   datasizewidth="16.00px" datasizeheight="16.00px" dataX="280.00" dataY="14.00"  >\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	      	<?xml version="1.0" encoding="UTF-8"?>\
        	      	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="280.0 603.0 16.0 16.0" preserveAspectRatio="none">\
        	      	  <g>\
        	      	    <defs>\
        	      	      <path id="mi-2226dae0-Path_386-11a5b" d="M288.0 611.0 C290.210000038147 611.0 292.0 609.210000038147 292.0 607.0 C292.0 604.789999961853 290.210000038147 603.0 288.0 603.0 C285.789999961853 603.0 284.0 604.789999961853 284.0 607.0 C284.0 609.210000038147 285.789999961853 611.0 288.0 611.0 Z M288.0 613.0 C285.32999992370605 613.0 280.0 614.3400000333786 280.0 617.0 L280.0 619.0 L296.0 619.0 L296.0 617.0 C296.0 614.3399999141693 290.67000007629395 613.0 288.0 613.0 Z "></path>\
        	      	    </defs>\
        	      	    <g style="mix-blend-mode:normal">\
        	      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-2226dae0-Path_386-11a5b" fill="#D8F3DC" fill-opacity="1.0"></use>\
        	      	    </g>\
        	      	  </g>\
        	      	</svg>\
\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
\
        	<div id="mi-2226dae0-Group_3" class="group firer ie-background commentable non-processed" customid="Group 3" datasizewidth="0.00px" datasizeheight="0.00px" dataX="155.50" dataY="12.50" >\
        	  <div id="mi-2226dae0-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Actividades"   datasizewidth="50.00px" datasizeheight="11.00px" dataX="155.50" dataY="33.00" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_2_0">Actividades</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
\
        	  <div id="mi-2226dae0-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="21.00px" datasizeheight="21.00px" dataX="170.00" dataY="12.50"   alt="image">\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	    		<img src="./images/27f23876-c680-4905-a78b-2d7b446306c4.png" />\
        	    	</div>\
        	    </div>\
        	  </div>\
\
        	</div>\
\
        	<div id="mi-2226dae0-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="60.00px" datasizeheight="36.00px" dataX="151.00" dataY="8.00"  >\
        	  <div class="clickableSpot"></div>\
        	</div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-eaff9538-c05c-4f16-8766-42cee8097fe7" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Login"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/eaff9538-c05c-4f16-8766-42cee8097fe7/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/eaff9538-c05c-4f16-8766-42cee8097fe7/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/eaff9538-c05c-4f16-8766-42cee8097fe7/custom-device-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/62d08b3d-3c10-42a4-b03b-c898c7047597/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/62d08b3d-3c10-42a4-b03b-c898c7047597/fonts-1732892862020.css" />\
      <div class="freeLayout">\
      <div id="s-Rectangle_2" class="rectangle manualfit firer commentable non-processed" customid="Rectangle_2"   datasizewidth="298.00px" datasizeheight="302.00px" datasizewidthpx="298.0" datasizeheightpx="302.0" dataX="29.00" dataY="110.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_2_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="265.00px" datasizeheight="66.00px" dataX="45.00" dataY="110.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">APP UAM DEPORTE</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="text firer focusin commentable non-processed" customid="Input_1"  datasizewidth="180.00px" datasizeheight="38.00px" dataX="134.00" dataY="193.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Usuario o correo electr&oacute;nico" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_2"   datasizewidth="85.00px" datasizeheight="40.00px" dataX="43.00" dataY="191.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_2_0">Usuario:</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_2" class="password firer focusin commentable non-processed" customid="Input_2"  datasizewidth="180.00px" datasizeheight="38.00px" dataX="134.00" dataY="262.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="password"  value="" maxlength="100"  tabindex="-1" placeholder="Contrase&ntilde;a"/></div></div></div></div></div>\
      <div id="s-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_3"   datasizewidth="84.00px" datasizeheight="40.00px" dataX="43.00" dataY="260.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_3_0">Contrase&ntilde;a</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_4"   datasizewidth="195.00px" datasizeheight="31.00px" dataX="92.00" dataY="366.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">&iquest;Olvidsate tu contrase&ntilde;a?</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_4" class="rectangle manualfit firer commentable non-processed" customid="Rectangle_4"   datasizewidth="296.00px" datasizeheight="70.00px" datasizewidthpx="296.0" datasizeheightpx="70.0" dataX="28.00" dataY="427.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_4_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Text_5" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_5"   datasizewidth="246.00px" datasizeheight="36.00px" dataX="67.00" dataY="444.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_5_0">&iquest;No tienes una cuenta? Registrate</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_1" class="button multiline manualfit firer click commentable non-processed" customid="Button_1"   datasizewidth="120.00px" datasizeheight="30.00px" dataX="130.00" dataY="318.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Iniciar Sesion</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Master_item_3" class="mi-67d8f83d m-62d08b3d-3c10-42a4-b03b-c898c7047597 masterinstance firer ie-background commentable non-processed" master="m-62d08b3d-3c10-42a4-b03b-c898c7047597" customid="Men&uacute;NoIniciado" datasizewidth="360.00px" datasizeheight="640.00px" dataX="-0.00" dataY="-3.21" dataAngle="0.0" >\
        <div class="masterInstanceRelativeSizeWrapper">	\
        	<div id="mi-67d8f83d-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" dataX="0.00" dataY="0.00" >\
        	  <div id="mi-67d8f83d-Dynamic_panel_1" class="dynamicpanel firer commentable hidden non-processed" customid="Dynamic panel 1" datasizewidth="360.00px" datasizeheight="640.00px" dataX="0.00" dataY="0.00" >\
        	    <div id="mi-67d8f83d-Panel_1" class="panel default firer commentable non-processed" customid="Panel 1"  datasizewidth="360.00px" datasizeheight="640.00px" >\
        	      <div class="backgroundLayer">\
        	        <div class="colorLayer"></div>\
        	        <div class="imageLayer"></div>\
        	      </div>\
        	      <div class="borderLayer">\
        	      	<div class="layoutWrapper scrollable">\
        	      	  <div class="paddingLayer">\
        	            <div class="freeLayout">\
        	            <div id="mi-67d8f83d-Dynamic_Panel_73" class="dynamicpanel firer ie-background commentable non-processed" customid="Basic slide menu" datasizewidth="300.00px" datasizeheight="640.00px" dataX="-0.00" dataY="-0.00" >\
        	              <div id="mi-67d8f83d-Panel_11" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="300.00px" datasizeheight="640.00px" >\
        	                <div class="backgroundLayer">\
        	                  <div class="colorLayer"></div>\
        	                  <div class="imageLayer"></div>\
        	                </div>\
        	                <div class="borderLayer">\
        	                	<div class="layoutWrapper scrollable">\
        	                	  <div class="paddingLayer">\
        	                      <div class="freeLayout">\
        	                      <div id="mi-67d8f83d-Rectangle_58" class="rectangle manualfit firer click commentable non-processed" customid="BG"   datasizewidth="359.50px" datasizeheight="748.00px" datasizewidthpx="359.4999999999998" datasizeheightpx="748.0" dataX="1.00" dataY="-1.00" >\
        	                        <div class="backgroundLayer">\
        	                          <div class="colorLayer"></div>\
        	                          <div class="imageLayer"></div>\
        	                        </div>\
        	                        <div class="borderLayer">\
        	                          <div class="paddingLayer">\
        	                            <div class="content">\
        	                              <div class="valign">\
        	                                <span id="rtr-mi-67d8f83d-Rectangle_58_0"></span>\
        	                              </div>\
        	                            </div>\
        	                          </div>\
        	                        </div>\
        	                      </div>\
        	                      <div id="mi-67d8f83d-Dynamic_Panel_7" class="dynamicpanel firer commentable non-processed" customid="Dropdown menu" datasizewidth="313.00px" datasizeheight="752.00px" dataX="0.00" dataY="0.00" >\
        	                        <div id="mi-67d8f83d-Panel_12" class="panel default firer commentable non-processed" customid="Expanded"  datasizewidth="313.00px" datasizeheight="752.00px" >\
        	                          <div class="backgroundLayer">\
        	                            <div class="colorLayer"></div>\
        	                            <div class="imageLayer"></div>\
        	                          </div>\
        	                          <div class="borderLayer">\
        	                          	<div class="layoutWrapper scrollable">\
        	                          	  <div class="paddingLayer">\
        	                                <table class="layout" summary="">\
        	                                  <tr>\
        	                                    <td class="layout vertical insertionpoint verticalalign Panel_12 Dynamic_Panel_7" valign="top" align="left" hSpacing="0" vSpacing="0"><div id="mi-67d8f83d-Dynamic_Panel_8" class="dynamicpanel firer ie-background commentable non-processed" customid="Open" datasizewidth="313.00px" datasizeheight="50.00px" dataX="0.00" dataY="0.00" >\
        	                                  <div id="mi-67d8f83d-Panel_99" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="313.00px" datasizeheight="50.00px" >\
        	                                    <div class="backgroundLayer">\
        	                                      <div class="colorLayer"></div>\
        	                                      <div class="imageLayer"></div>\
        	                                    </div>\
        	                                    <div class="borderLayer">\
        	                                    	<div class="layoutWrapper scrollable">\
        	                                    	  <div class="paddingLayer">\
        	                                          <div class="freeLayout">\
        	                                          <div id="mi-67d8f83d-Table_5" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="313.00px" datasizeheight="50.00px" dataX="0.00" dataY="0.00" originalwidth="313.0px" originalheight="50.000000000000085px" >\
        	                                            <div class="backgroundLayer">\
        	                                              <div class="colorLayer"></div>\
        	                                              <div class="imageLayer"></div>\
        	                                            </div>\
        	                                            <div class="borderLayer">\
        	                                              <div class="paddingLayer">\
        	                                                <table summary="">\
        	                                                  <tbody>\
        	                                                    <tr>\
        	                                                      <td id="mi-67d8f83d-Cell_99" customid="Cell" class="cellcontainer firer ie-background non-processed"    datasizewidth="313.00px" datasizeheight="50.00px" dataX="0.00" dataY="0.00" originalwidth="313.0px" originalheight="50.0px" >\
        	                                                        <div class="cellContainerChild">\
        	                                                          <div class="backgroundLayer">\
        	                                                            <div class="colorLayer"></div>\
        	                                                            <div class="imageLayer"></div>\
        	                                                          </div>\
        	                                                          <div class="borderLayer">\
        	                                                        	  <div class="layout scrollable">\
        	                                                        	    <div class="paddingLayer">\
        	                                                                <div class="left ghostHLayout">\
        	                                                                <table class="layout" summary="">\
        	                                                                  <tr>\
        	                                                                    <td class="layout horizontal insertionpoint verticalalign Cell_99 Table_5" valign="middle" align="left" hSpacing="15" vSpacing="0"><div id="mi-67d8f83d-Path_6" class="path firer click commentable non-processed" customid="Menu icon"   datasizewidth="18.83px" datasizeheight="13.56px" dataX="11.08" dataY="3.94"  >\
        	                                                                  <div class="borderLayer">\
        	                                                                  	<div class="imageViewport">\
        	                                                                    	<?xml version="1.0" encoding="UTF-8"?>\
        	                                                                    	<svg xmlns="http://www.w3.org/2000/svg" width="18.833333333333336" height="13.56" viewBox="11.083333015441895 3.9399986267089844 18.833333333333336 13.56" preserveAspectRatio="none">\
        	                                                                    	  <g>\
        	                                                                    	    <defs>\
        	                                                                    	      <path id="mi-67d8f83d-Path_6-eaff9" d="M29.91666634877523 3.9399986267089844 L29.91666634877523 5.44666529337565 L11.083333015441895 5.44666529337565 L11.083333015441895 3.9399986267089844 L29.91666634877523 3.9399986267089844 Z M29.91666634877523 15.993331960042315 L29.91666634877523 17.499998626708987 L11.083333015441895 17.499998626708987 L11.083333015441895 15.993331960042315 L29.91666634877523 15.993331960042315 Z M29.91666634877523 9.96666529337565 L29.91666634877523 11.473331960042318 L11.083333015441895 11.473331960042318 L11.083333015441895 9.96666529337565 L29.91666634877523 9.96666529337565 Z "></path>\
        	                                                                    	    </defs>\
        	                                                                    	    <g style="mix-blend-mode:normal">\
        	                                                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-67d8f83d-Path_6-eaff9" fill="#000000" fill-opacity="1.0"></use>\
        	                                                                    	    </g>\
        	                                                                    	  </g>\
        	                                                                    	</svg>\
\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div></td> \
        	                                                                  </tr>\
        	                                                                </table>\
        	                                                                </div>\
\
        	                                                              </div>\
        	                                                            </div>\
        	                                                          </div>\
        	                                                        </div>\
        	                                                      </td>\
        	                                                    </tr>\
        	                                                  </tbody>\
        	                                                </table>\
        	                                              </div>\
        	                                            </div>\
        	                                          </div>\
        	                                          </div>\
\
        	                                        </div>\
        	                                      </div>\
        	                                    </div>\
        	                                  </div>\
        	                                </div><div id="mi-67d8f83d-Dynamic_Panel_66" class="dynamicpanel firer ie-background commentable non-processed" customid="Category 1" datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="50.00" >\
        	                                  <div id="mi-67d8f83d-Panel_100" class="panel default firer ie-background commentable non-processed" customid="Collapsed"  datasizewidth="313.00px" datasizeheight="56.00px" >\
        	                                    <div class="backgroundLayer">\
        	                                      <div class="colorLayer"></div>\
        	                                      <div class="imageLayer"></div>\
        	                                    </div>\
        	                                    <div class="borderLayer">\
        	                                    	<div class="layoutWrapper scrollable">\
        	                                    	  <div class="paddingLayer">\
        	                                          <div class="freeLayout">\
        	                                          <div id="mi-67d8f83d-Table_6" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="313.00px" datasizeheight="56.00px" dataX="-1.00" dataY="0.00" originalwidth="313.0px" originalheight="56.0px" >\
        	                                            <div class="backgroundLayer">\
        	                                              <div class="colorLayer"></div>\
        	                                              <div class="imageLayer"></div>\
        	                                            </div>\
        	                                            <div class="borderLayer">\
        	                                              <div class="paddingLayer">\
        	                                                <table summary="">\
        	                                                  <tbody>\
        	                                                    <tr>\
        	                                                      <td id="mi-67d8f83d-Cell_100" customid="Cell 1" class="cellcontainer firer click ie-background non-processed"    datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="313.0px" originalheight="55.999999999999915px" >\
        	                                                        <div class="cellContainerChild">\
        	                                                          <div class="backgroundLayer">\
        	                                                            <div class="colorLayer"></div>\
        	                                                            <div class="imageLayer"></div>\
        	                                                          </div>\
        	                                                          <div class="borderLayer">\
        	                                                        	  <div class="layout scrollable">\
        	                                                        	    <div class="paddingLayer">\
        	                                                                <div class="left ghostHLayout">\
        	                                                                <table class="layout" summary="">\
        	                                                                  <tr>\
        	                                                                    <td class="layout horizontal insertionpoint verticalalign Cell_100 Table_6" valign="middle" align="left" hSpacing="21" vSpacing="0"><div id="mi-67d8f83d-Path_72" class="path firer commentable non-processed" customid="Home"   datasizewidth="20.00px" datasizeheight="17.00px" dataX="0.00" dataY="19.50"  >\
        	                                                                  <div class="borderLayer">\
        	                                                                  	<div class="imageViewport">\
        	                                                                    	<?xml version="1.0" encoding="UTF-8"?>\
        	                                                                    	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="17.0" viewBox="0.0 19.499999999999957 20.0 17.0" preserveAspectRatio="none">\
        	                                                                    	  <g>\
        	                                                                    	    <defs>\
        	                                                                    	      <path id="mi-67d8f83d-Path_72-eaff9" d="M8.0 36.49999999999996 L8.0 30.499999999999957 L12.0 30.499999999999957 L12.0 36.49999999999996 L17.0 36.49999999999996 L17.0 28.499999999999957 L20.0 28.499999999999957 L10.0 19.499999999999957 L0.0 28.499999999999957 L3.0 28.499999999999957 L3.0 36.49999999999996 Z "></path>\
        	                                                                    	    </defs>\
        	                                                                    	    <g style="mix-blend-mode:normal">\
        	                                                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-67d8f83d-Path_72-eaff9" fill="#252222" fill-opacity="1.0"></use>\
        	                                                                    	    </g>\
        	                                                                    	  </g>\
        	                                                                    	</svg>\
\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div><div id="mi-67d8f83d-Paragraph_25" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="73.37px" datasizeheight="17.00px" dataX="41.00" dataY="19.50" >\
        	                                                                  <div class="backgroundLayer">\
        	                                                                    <div class="colorLayer"></div>\
        	                                                                    <div class="imageLayer"></div>\
        	                                                                  </div>\
        	                                                                  <div class="borderLayer">\
        	                                                                    <div class="paddingLayer">\
        	                                                                      <div class="content">\
        	                                                                        <div class="valign">\
        	                                                                          <span id="rtr-mi-67d8f83d-Paragraph_25_0">Inicio</span>\
        	                                                                        </div>\
        	                                                                      </div>\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div></td> \
        	                                                                  </tr>\
        	                                                                </table>\
        	                                                                </div>\
\
        	                                                              </div>\
        	                                                            </div>\
        	                                                          </div>\
        	                                                        </div>\
        	                                                      </td>\
        	                                                    </tr>\
        	                                                  </tbody>\
        	                                                </table>\
        	                                              </div>\
        	                                            </div>\
        	                                          </div>\
        	                                          </div>\
\
        	                                        </div>\
        	                                      </div>\
        	                                    </div>\
        	                                  </div>\
        	                                </div><div id="mi-67d8f83d-Dynamic_Panel_67" class="dynamicpanel firer ie-background commentable non-processed" customid="Category 2" datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="106.00" >\
        	                                  <div id="mi-67d8f83d-Panel_101" class="panel default firer ie-background commentable non-processed" customid="Collapsed"  datasizewidth="313.00px" datasizeheight="56.00px" >\
        	                                    <div class="backgroundLayer">\
        	                                      <div class="colorLayer"></div>\
        	                                      <div class="imageLayer"></div>\
        	                                    </div>\
        	                                    <div class="borderLayer">\
        	                                    	<div class="layoutWrapper scrollable">\
        	                                    	  <div class="paddingLayer">\
        	                                          <div class="freeLayout">\
        	                                          <div id="mi-67d8f83d-Table_7" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="313.00px" datasizeheight="56.00px" dataX="-1.00" dataY="0.00" originalwidth="313.0px" originalheight="56.0px" >\
        	                                            <div class="backgroundLayer">\
        	                                              <div class="colorLayer"></div>\
        	                                              <div class="imageLayer"></div>\
        	                                            </div>\
        	                                            <div class="borderLayer">\
        	                                              <div class="paddingLayer">\
        	                                                <table summary="">\
        	                                                  <tbody>\
        	                                                    <tr>\
        	                                                      <td id="mi-67d8f83d-Cell_101" customid="Cell" class="cellcontainer firer click ie-background non-processed"    datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="313.0px" originalheight="55.999999999999915px" >\
        	                                                        <div class="cellContainerChild">\
        	                                                          <div class="backgroundLayer">\
        	                                                            <div class="colorLayer"></div>\
        	                                                            <div class="imageLayer"></div>\
        	                                                          </div>\
        	                                                          <div class="borderLayer">\
        	                                                        	  <div class="layout scrollable">\
        	                                                        	    <div class="paddingLayer">\
        	                                                                <div class="left ghostHLayout">\
        	                                                                <table class="layout" summary="">\
        	                                                                  <tr>\
        	                                                                    <td class="layout horizontal insertionpoint verticalalign Cell_101 Table_7" valign="middle" align="left" hSpacing="20" vSpacing="0">\
        	                                                                <div id="mi-67d8f83d-Image_1" class="image firer ie-background commentable non-processed" customid="clases"   datasizewidth="23.00px" datasizeheight="27.00px" dataX="0.00" dataY="14.50"   alt="image">\
        	                                                                  <div class="borderLayer">\
        	                                                                  	<div class="imageViewport">\
        	                                                                  		<img src="./images/d242eeb4-3976-4926-b48a-16a8c564faed.png" />\
        	                                                                  	</div>\
        	                                                                  </div>\
        	                                                                </div>\
        	                                                                <div id="mi-67d8f83d-Paragraph_26" class="richtext autofit firer click ie-background commentable non-processed" customid="Clases"   datasizewidth="45.85px" datasizeheight="17.00px" dataX="43.00" dataY="19.50" >\
        	                                                                  <div class="backgroundLayer">\
        	                                                                    <div class="colorLayer"></div>\
        	                                                                    <div class="imageLayer"></div>\
        	                                                                  </div>\
        	                                                                  <div class="borderLayer">\
        	                                                                    <div class="paddingLayer">\
        	                                                                      <div class="content">\
        	                                                                        <div class="valign">\
        	                                                                          <span id="rtr-mi-67d8f83d-Paragraph_26_0">Clases</span>\
        	                                                                        </div>\
        	                                                                      </div>\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div></td> \
        	                                                                  </tr>\
        	                                                                </table>\
        	                                                                </div>\
\
        	                                                              </div>\
        	                                                            </div>\
        	                                                          </div>\
        	                                                        </div>\
        	                                                      </td>\
        	                                                    </tr>\
        	                                                  </tbody>\
        	                                                </table>\
        	                                              </div>\
        	                                            </div>\
        	                                          </div>\
        	                                          </div>\
\
        	                                        </div>\
        	                                      </div>\
        	                                    </div>\
        	                                  </div>\
        	                                </div><div id="mi-67d8f83d-Dynamic_Panel_69" class="dynamicpanel firer ie-background commentable non-processed" customid="Category 4" datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="162.00" >\
        	                                  <div id="mi-67d8f83d-Panel_103" class="panel default firer ie-background commentable non-processed" customid="Collapsed"  datasizewidth="313.00px" datasizeheight="56.00px" >\
        	                                    <div class="backgroundLayer">\
        	                                      <div class="colorLayer"></div>\
        	                                      <div class="imageLayer"></div>\
        	                                    </div>\
        	                                    <div class="borderLayer">\
        	                                    	<div class="layoutWrapper scrollable">\
        	                                    	  <div class="paddingLayer">\
        	                                          <div class="freeLayout">\
        	                                          <div id="mi-67d8f83d-Table_9" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="313.00px" datasizeheight="56.00px" dataX="-1.00" dataY="0.00" originalwidth="313.0px" originalheight="56.0px" >\
        	                                            <div class="backgroundLayer">\
        	                                              <div class="colorLayer"></div>\
        	                                              <div class="imageLayer"></div>\
        	                                            </div>\
        	                                            <div class="borderLayer">\
        	                                              <div class="paddingLayer">\
        	                                                <table summary="">\
        	                                                  <tbody>\
        	                                                    <tr>\
        	                                                      <td id="mi-67d8f83d-Cell_146" customid="Cell" class="cellcontainer firer click ie-background non-processed"    datasizewidth="313.00px" datasizeheight="56.00px" dataX="0.00" dataY="0.00" originalwidth="313.0px" originalheight="55.999999999999915px" >\
        	                                                        <div class="cellContainerChild">\
        	                                                          <div class="backgroundLayer">\
        	                                                            <div class="colorLayer"></div>\
        	                                                            <div class="imageLayer"></div>\
        	                                                          </div>\
        	                                                          <div class="borderLayer">\
        	                                                        	  <div class="layout scrollable">\
        	                                                        	    <div class="paddingLayer">\
        	                                                                <div class="left ghostHLayout">\
        	                                                                <table class="layout" summary="">\
        	                                                                  <tr>\
        	                                                                    <td class="layout horizontal insertionpoint verticalalign Cell_146 Table_9" valign="middle" align="left" hSpacing="20" vSpacing="0"><div id="mi-67d8f83d-Path_19" class="path firer click commentable non-processed" customid="settings-icon"   datasizewidth="18.45px" datasizeheight="18.97px" dataX="0.00" dataY="18.52"  >\
        	                                                                  <div class="borderLayer">\
        	                                                                  	<div class="imageViewport">\
        	                                                                    	<?xml version="1.0" encoding="UTF-8"?>\
        	                                                                    	<svg xmlns="http://www.w3.org/2000/svg" width="18.449999999999996" height="18.967581909688953" viewBox="0.0 18.51620904515548 18.449999999999996 18.967581909688953" preserveAspectRatio="none">\
        	                                                                    	  <g>\
        	                                                                    	    <defs>\
        	                                                                    	      <path id="mi-67d8f83d-Path_19-eaff9" d="M16.273551557643966 28.92941095336657 C16.31148672015614 28.62592965326919 16.33993809380676 28.322448353171808 16.33993809380676 27.999999432955477 C16.33993809380676 27.67755054100305 16.311486721922634 27.37406921264177 16.273551557643966 27.07058791254439 L18.274631325399763 25.505762446551813 C18.45482334909908 25.3635055782987 18.5022423004728 25.10744324370699 18.388436812936284 24.898799846357054 L16.491678644931806 21.61740817953152 C16.406324523979936 21.46566752948283 16.245100092135672 21.38031340853096 16.074391850231933 21.38031340853096 C16.017489106463678 21.38031340853096 15.960586362695416 21.389797199159002 15.913167404255717 21.40876478041509 L13.551703476045699 22.357143864417328 C13.058546370453431 21.977792225163654 12.527454024623268 21.664827115006798 11.948942769815229 21.427732344006237 L11.588558722416604 18.91452768095583 C11.560107256908307 18.68691734358702 11.360947613090048 18.51620904515548 11.123852842089487 18.51620904515548 L7.330336506080532 18.51620904515548 C7.093241735079972 18.51620904515548 6.894082119525611 18.68691728705922 6.865630745874985 18.914528248000305 L6.50524669847636 21.427732911050718 C5.926735443668323 21.664827682051275 5.395643210893755 21.987276545739803 4.90248599224589 22.357144431461805 L2.541022064035868 21.408765347459564 C2.4841193202676086 21.38979776620348 2.42721657649935 21.380313975575437 2.370313822132129 21.380313975575437 C2.209089376155914 21.380313975575437 2.0478649301797 21.465668096527306 1.9625108092278305 21.617408746575997 L0.06575264122335334 24.89880041340153 C-0.057536635174713524 25.10744381075147 -6.338949394422144E-4 25.363506173607078 0.17955812875987087 25.505763013596294 L2.1806378965156696 27.070588479588867 C2.142702734003497 27.37406977968625 2.114251360352874 27.687034861579203 2.114251360352874 27.999999999999957 C2.114251360352874 28.31296511015681 2.1427027322370034 28.625930220313666 2.1806378965156696 28.929411520411048 L0.17955812875987087 30.49423698640362 C-6.338949394422144E-4 30.636493854656738 -0.0480528463131642 30.892556189248445 0.06575264122335334 31.101199586598383 L1.9625108092278305 34.382591253423925 C2.0478649301797 34.53433190347261 2.209089362023965 34.61968602442448 2.3797976039277042 34.61968602442448 C2.4367003476959628 34.61968602442448 2.4936030914642213 34.610202233796436 2.5410220499039182 34.59123465254035 L4.9024859781139405 33.64285556853811 C5.395643083706208 34.02220720779179 5.926735429536374 34.33517231794864 6.505246684344411 34.572267088949204 L6.865630731743038 37.085471751999606 C6.894082103627166 37.31308272707265 7.093241706816074 37.48379095484444 7.330336491948581 37.48379095484444 L11.123852827957538 37.48379095484444 C11.360947598958095 37.48379095484444 11.560107214512456 37.3130827129407 11.588558588163082 37.085471751999606 L11.94894263556171 34.572267088949204 C12.527453890369745 34.33517231794864 13.058546123144314 34.01272345426011 13.551703341792177 33.64285556853811 L15.913167270002198 34.59123465254035 C15.970070013770457 34.610202233796436 16.02697275753872 34.61968602442448 16.083875511905934 34.61968602442448 C16.245099957882154 34.61968602442448 16.406324403858363 34.53433190347261 16.491678524810233 34.382591253423925 L18.38843669281471 31.101199586598383 C18.50224218035123 30.892556189248445 18.45482322897751 30.636493826392837 18.274631205278194 30.49423698640362 L16.273551437522396 28.929411520411048 Z M14.395760953230639 27.30768268354495 C14.433696115742812 27.601680201846754 14.443179908137349 27.800839789137218 14.443179908137349 27.999999432955477 C14.443179908137349 28.199159034377892 14.42421232688126 28.407802445859776 14.395760953230639 28.692316182366007 L14.262987880905047 29.763984542766316 L15.107045252100367 30.427849890262323 L16.131294703522805 31.22448829595197 L15.467429356026795 32.37202702377247 L14.262987937432847 31.888353699975777 L13.276673726248312 31.49003449713095 L12.423132573257416 32.13493228103581 C12.01532956035312 32.43841358113319 11.626494167567767 32.66602457033818 11.237658718254618 32.82724903044634 L10.232376943478933 33.23505204335064 L10.080636293430242 34.306720403750944 L9.890960473803403 35.58703218976509 L8.56322977881139 35.58703218976509 L8.383037755112078 34.306720403750944 L8.231297105063387 33.23505204335064 L7.226015330287699 32.82724903044634 C6.818212317383401 32.6565407885426 6.438860706393625 32.43841360939709 6.05950903887605 32.15389990115476 L5.19648404756178 31.490034553658752 L4.191202272786095 31.897837566563048 L2.9867608541921458 32.38151089035974 L2.322895506696139 31.233972162539242 L3.347144958118572 30.437333756849597 L4.191202329313893 29.773468409353587 L4.0584292569883 28.70180004895328 C4.029977885104172 28.407802530651473 4.0110103020815915 28.189675323242064 4.0110103020815915 27.999999517747177 C4.0110103020815915 27.810323712252288 4.029977883337678 27.592196504842878 4.0584292569883 27.307682768336647 L4.191202329313893 26.23601440793634 L3.347144958118572 25.57214906044033 L2.322895506696139 24.775510654750683 L2.9867608541921458 23.627971926930186 L4.191202272786095 24.11164525072688 L5.1775164839706305 24.509964453571705 L6.0310576369615285 23.865066669666845 C6.438860649865826 23.561585369569464 6.827696042651177 23.33397438036448 7.216531491964326 23.172749920256315 L8.221813266740014 22.76494690735202 L8.373553916788705 21.693278546951714 L8.56322973641554 20.41296676093757 L9.88147664961198 20.41296676093757 L10.061668673311296 21.693278546951714 L10.213409323359986 22.76494690735202 L11.218691098135672 23.172749920256315 C11.626494111039971 23.343458162160054 12.005845722029747 23.561585341305566 12.385197389547319 23.8460990495479 L13.248222380861588 24.509964397043905 L14.25350415563727 24.102161384139606 L15.457945574231218 23.618488060342912 L16.121810921727228 24.766026788163412 L15.107045252100367 25.572149032176434 L14.262987880905047 26.236014379672444 L14.395760953230639 27.30768274007275 Z M9.22709467408501 24.206483549168915 C7.1311768622622695 24.206483549168915 5.433578338076054 25.904082073355127 5.433578338076054 27.999999885177864 C5.433578338076054 30.095917697000605 7.1311768622622695 31.79351622118682 9.22709467408501 31.79351622118682 C11.323012485907746 31.79351622118682 13.020611010093965 30.095917697000605 13.020611010093965 27.999999885177864 C13.020611010093965 25.904082073355127 11.323012485907746 24.206483549168915 9.22709467408501 24.206483549168915 Z M9.22709467408501 29.896758053182346 C8.183877659071428 29.896758053182346 7.330336506080532 29.043216900191446 7.330336506080532 27.999999885177864 C7.330336506080532 26.956782870164282 8.183877659071428 26.10324171717339 9.22709467408501 26.10324171717339 C10.270311689098591 26.10324171717339 11.123852842089487 26.956782870164282 11.123852842089487 27.999999885177864 C11.123852842089487 29.043216900191446 10.270311689098591 29.896758053182346 9.22709467408501 29.896758053182346 Z "></path>\
        	                                                                    	    </defs>\
        	                                                                    	    <g style="mix-blend-mode:normal">\
        	                                                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-67d8f83d-Path_19-eaff9" fill="#313033" fill-opacity="1.0"></use>\
        	                                                                    	    </g>\
        	                                                                    	  </g>\
        	                                                                    	</svg>\
\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div><div id="mi-67d8f83d-Paragraph_37" class="richtext autofit firer click ie-background commentable non-processed" customid="Ajustes"   datasizewidth="49.19px" datasizeheight="17.00px" dataX="38.45" dataY="19.50" >\
        	                                                                  <div class="backgroundLayer">\
        	                                                                    <div class="colorLayer"></div>\
        	                                                                    <div class="imageLayer"></div>\
        	                                                                  </div>\
        	                                                                  <div class="borderLayer">\
        	                                                                    <div class="paddingLayer">\
        	                                                                      <div class="content">\
        	                                                                        <div class="valign">\
        	                                                                          <span id="rtr-mi-67d8f83d-Paragraph_37_0">Ajustes</span>\
        	                                                                        </div>\
        	                                                                      </div>\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div></td> \
        	                                                                  </tr>\
        	                                                                </table>\
        	                                                                </div>\
\
        	                                                              </div>\
        	                                                            </div>\
        	                                                          </div>\
        	                                                        </div>\
        	                                                      </td>\
        	                                                    </tr>\
        	                                                  </tbody>\
        	                                                </table>\
        	                                              </div>\
        	                                            </div>\
        	                                          </div>\
        	                                          </div>\
\
        	                                        </div>\
        	                                      </div>\
        	                                    </div>\
        	                                  </div>\
        	                                </div></td> \
        	                                  </tr>\
        	                                </table>\
\
        	                              </div>\
        	                            </div>\
        	                          </div>\
        	                        </div>\
        	                        <div id="mi-67d8f83d-Panel_106" class="panel hidden firer ie-background commentable non-processed" customid="Collapsed"  datasizewidth="75.00px" datasizeheight="748.00px" >\
        	                          <div class="backgroundLayer">\
        	                            <div class="colorLayer"></div>\
        	                            <div class="imageLayer"></div>\
        	                          </div>\
        	                          <div class="borderLayer">\
        	                          	<div class="layoutWrapper scrollable">\
        	                          	  <div class="paddingLayer">\
        	                                <table class="layout" summary="">\
        	                                  <tr>\
        	                                    <td class="layout vertical insertionpoint verticalalign Panel_106 Dynamic_Panel_7" valign="top" align="center" hSpacing="0" vSpacing="0"><div id="mi-67d8f83d-Dynamic_Panel_72" class="dynamicpanel firer ie-background commentable non-processed" customid="Open" datasizewidth="239.00px" datasizeheight="50.00px" dataX="0.00" dataY="0.00" >\
        	                                  <div id="mi-67d8f83d-Panel_107" class="panel default firer ie-background commentable non-processed" customid="Panel"  datasizewidth="239.00px" datasizeheight="50.00px" >\
        	                                    <div class="backgroundLayer">\
        	                                      <div class="colorLayer"></div>\
        	                                      <div class="imageLayer"></div>\
        	                                    </div>\
        	                                    <div class="borderLayer">\
        	                                    	<div class="layoutWrapper scrollable">\
        	                                    	  <div class="paddingLayer">\
        	                                          <div class="freeLayout">\
        	                                          <div id="mi-67d8f83d-Table_26" class="table firer ie-background commentable non-processed" customid="Table"  datasizewidth="77.00px" datasizeheight="50.00px" dataX="0.00" dataY="-0.00" originalwidth="77.0px" originalheight="50.000000000000085px" >\
        	                                            <div class="backgroundLayer">\
        	                                              <div class="colorLayer"></div>\
        	                                              <div class="imageLayer"></div>\
        	                                            </div>\
        	                                            <div class="borderLayer">\
        	                                              <div class="paddingLayer">\
        	                                                <table summary="">\
        	                                                  <tbody>\
        	                                                    <tr>\
        	                                                      <td id="mi-67d8f83d-Cell_149" customid="Cell" class="cellcontainer firer ie-background non-processed"    datasizewidth="77.00px" datasizeheight="50.00px" dataX="0.00" dataY="0.00" originalwidth="77.0px" originalheight="50.0px" >\
        	                                                        <div class="cellContainerChild">\
        	                                                          <div class="backgroundLayer">\
        	                                                            <div class="colorLayer"></div>\
        	                                                            <div class="imageLayer"></div>\
        	                                                          </div>\
        	                                                          <div class="borderLayer">\
        	                                                        	  <div class="layout scrollable">\
        	                                                        	    <div class="paddingLayer">\
        	                                                                <div class="left ghostHLayout">\
        	                                                                <table class="layout" summary="">\
        	                                                                  <tr>\
        	                                                                    <td class="layout horizontal insertionpoint verticalalign Cell_149 Table_26" valign="middle" align="left" hSpacing="15" vSpacing="0"><div id="mi-67d8f83d-Path_41" class="path firer click commentable non-processed" customid="Menu icon"   datasizewidth="18.83px" datasizeheight="13.56px" dataX="80.00" dataY="400.00"  >\
        	                                                                  <div class="borderLayer">\
        	                                                                  	<div class="imageViewport">\
        	                                                                    	<?xml version="1.0" encoding="UTF-8"?>\
        	                                                                    	<svg xmlns="http://www.w3.org/2000/svg" width="18.833333333333336" height="13.56" viewBox="80.0 400.0 18.833333333333336 13.56" preserveAspectRatio="none">\
        	                                                                    	  <g>\
        	                                                                    	    <defs>\
        	                                                                    	      <path id="mi-67d8f83d-Path_41-eaff9" d="M98.83333333333334 400.0 L98.83333333333334 401.50666666666666 L80.0 401.50666666666666 L80.0 400.0 L98.83333333333334 400.0 Z M98.83333333333334 412.05333333333334 L98.83333333333334 413.56 L80.0 413.56 L80.0 412.05333333333334 L98.83333333333334 412.05333333333334 Z M98.83333333333334 406.02666666666664 L98.83333333333334 407.53333333333336 L80.0 407.53333333333336 L80.0 406.02666666666664 L98.83333333333334 406.02666666666664 Z "></path>\
        	                                                                    	    </defs>\
        	                                                                    	    <g style="mix-blend-mode:normal">\
        	                                                                    	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-67d8f83d-Path_41-eaff9" fill="#000000" fill-opacity="1.0"></use>\
        	                                                                    	    </g>\
        	                                                                    	  </g>\
        	                                                                    	</svg>\
\
        	                                                                    </div>\
        	                                                                  </div>\
        	                                                                </div></td> \
        	                                                                  </tr>\
        	                                                                </table>\
        	                                                                </div>\
\
        	                                                              </div>\
        	                                                            </div>\
        	                                                          </div>\
        	                                                        </div>\
        	                                                      </td>\
        	                                                    </tr>\
        	                                                  </tbody>\
        	                                                </table>\
        	                                              </div>\
        	                                            </div>\
        	                                          </div>\
        	                                          </div>\
\
        	                                        </div>\
        	                                      </div>\
        	                                    </div>\
        	                                  </div>\
        	                                </div></td> \
        	                                  </tr>\
        	                                </table>\
\
        	                              </div>\
        	                            </div>\
        	                          </div>\
        	                        </div>\
        	                      </div>\
        	                      </div>\
\
        	                    </div>\
        	                  </div>\
        	                </div>\
        	              </div>\
        	            </div>\
        	            </div>\
\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	  <div id="mi-67d8f83d-Path_147" class="path firer click commentable non-processed" customid="Menu"   datasizewidth="18.00px" datasizeheight="12.00px" dataX="16.00" dataY="29.00"  >\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	      	<?xml version="1.0" encoding="UTF-8"?>\
        	      	<svg xmlns="http://www.w3.org/2000/svg" width="18.0" height="12.0" viewBox="16.000000000000455 29.000000000000114 18.0 12.0" preserveAspectRatio="none">\
        	      	  <g>\
        	      	    <defs>\
        	      	      <path id="mi-67d8f83d-Path_147-eaff9" d="M16.000000000000455 41.000000000000114 L34.000000000000455 41.000000000000114 L34.000000000000455 39.000000000000114 L16.000000000000455 39.000000000000114 L16.000000000000455 41.000000000000114 Z M16.000000000000455 36.000000000000114 L34.000000000000455 36.000000000000114 L34.000000000000455 34.000000000000114 L16.000000000000455 34.000000000000114 L16.000000000000455 36.000000000000114 Z M16.000000000000455 29.000000000000114 L16.000000000000455 31.000000000000114 L34.000000000000455 31.000000000000114 L34.000000000000455 29.000000000000114 L16.000000000000455 29.000000000000114 Z "></path>\
        	      	    </defs>\
        	      	    <g style="mix-blend-mode:normal">\
        	      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-67d8f83d-Path_147-eaff9" fill="#FFFFFF" fill-opacity="1.0"></use>\
        	      	    </g>\
        	      	  </g>\
        	      	</svg>\
\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
        </div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer swiperight ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="43.00px" datasizeheight="539.00px" dataX="-31.00" dataY="49.88"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer swipeleft ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="65.00px" datasizeheight="530.00px" dataX="327.50" dataY="59.50"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
      <div id="loadMark-m-62d08b3d-3c10-42a4-b03b-c898c7047597" class="masterInstanceLoadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;