var content='<div class="ui-page " deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-11a5b772-fd90-44b1-a192-02f5b4e781f9" class="template growth-both devMobile devAndroid android-device canvas firer commentable non-processed" alignment="left" name="Template 2"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/templates/11a5b772-fd90-44b1-a192-02f5b4e781f9/custom-device-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/c3a5fa41-70da-4c97-bebb-cfe2956ccbec/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/4175d222-ff93-4208-87a0-713c85ec4c4c/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/masters/4175d222-ff93-4208-87a0-713c85ec4c4c/fonts-1732892862020.css" />\
      <div class="freeLayout">\
      <div id="t-Master_item_3" class="mi-a5c4e233 m-4175d222-ff93-4208-87a0-713c85ec4c4c masterinstance firer ie-background commentable non-processed" master="m-4175d222-ff93-4208-87a0-713c85ec4c4c" customid="HeaderIniciado" datasizewidth="360.00px" datasizeheight="59.00px" dataX="0.00" dataY="0.00" dataAngle="0.0" >\
        <div class="masterInstanceRelativeSizeWrapper">	\
        	<div id="mi-a5c4e233-Rectangle_3" class="rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="360.00px" datasizeheight="59.00px" datasizewidthpx="360.0" datasizeheightpx="59.0" dataX="0.00" dataY="0.00" >\
        	  <div class="backgroundLayer">\
        	    <div class="colorLayer"></div>\
        	    <div class="imageLayer"></div>\
        	  </div>\
        	  <div class="borderLayer">\
        	    <div class="paddingLayer">\
        	      <div class="content">\
        	        <div class="valign">\
        	          <span id="rtr-mi-a5c4e233-Rectangle_3_0"></span>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
        	<div id="mi-a5c4e233-Image_3" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="50.00px" datasizeheight="48.33px" dataX="301.00" dataY="5.33"   alt="image">\
        	  <div class="borderLayer">\
        	  	<div class="imageViewport">\
        	  		<img src="./images/e8aec7fd-fdca-4681-bfe0-a7ff6a7b9267.png" />\
        	  	</div>\
        	  </div>\
        	</div>\
\
        </div>\
      </div>\
      <div id="t-Master_item_2" class="mi-2226dae0 m-c3a5fa41-70da-4c97-bebb-cfe2956ccbec masterinstance firer ie-background commentable non-processed" master="m-c3a5fa41-70da-4c97-bebb-cfe2956ccbec" customid="Footer" datasizewidth="360.00px" datasizeheight="51.00px" dataX="0.00" dataY="589.00" dataAngle="0.0" >\
        <div class="masterInstanceRelativeSizeWrapper">	\
        	<div id="mi-2226dae0-Rectangle_1" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 1"   datasizewidth="360.00px" datasizeheight="51.00px" datasizewidthpx="359.9999999999999" datasizeheightpx="50.999999999999886" dataX="0.00" dataY="0.00" >\
        	  <div class="backgroundLayer">\
        	    <div class="colorLayer"></div>\
        	    <div class="imageLayer"></div>\
        	  </div>\
        	  <div class="borderLayer">\
        	    <div class="paddingLayer">\
        	      <div class="content">\
        	        <div class="valign">\
        	          <span id="rtr-mi-2226dae0-Rectangle_1_0"></span>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
        	<div id="mi-2226dae0-Group_1" class="group firer ie-background commentable non-processed" customid="Group 1" datasizewidth="0.00px" datasizeheight="0.00px" dataX="61.00" dataY="14.00" >\
        	  <div id="mi-2226dae0-Text_1" class="richtext manualfit firer click ie-background commentable non-processed" customid="Inicio"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="61.00" dataY="32.50" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_1_0">Inicio</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	  <div id="mi-2226dae0-Path_72" class="path firer click commentable non-processed" customid="Home"   datasizewidth="20.00px" datasizeheight="17.00px" dataX="63.00" dataY="14.00"  >\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	      	<?xml version="1.0" encoding="UTF-8"?>\
        	      	<svg xmlns="http://www.w3.org/2000/svg" width="20.0" height="17.0" viewBox="63.0 603.0 20.0 17.0" preserveAspectRatio="none">\
        	      	  <g>\
        	      	    <defs>\
        	      	      <path id="mi-2226dae0-Path_72-11a5b" d="M71.0 620.0 L71.0 614.0 L75.0 614.0 L75.0 620.0 L80.0 620.0 L80.0 612.0 L83.0 612.0 L73.0 603.0 L63.0 612.0 L66.0 612.0 L66.0 620.0 Z "></path>\
        	      	    </defs>\
        	      	    <g style="mix-blend-mode:normal">\
        	      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-2226dae0-Path_72-11a5b" fill="#D8F3DC" fill-opacity="1.0"></use>\
        	      	    </g>\
        	      	  </g>\
        	      	</svg>\
\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
\
        	<div id="mi-2226dae0-Group_2" class="group firer ie-background commentable non-processed" customid="Group 2" datasizewidth="0.00px" datasizeheight="0.00px" dataX="276.00" dataY="14.00" >\
        	  <div id="mi-2226dae0-Text_3" class="richtext manualfit firer ie-background commentable non-processed" customid="Perfil"   datasizewidth="24.00px" datasizeheight="11.00px" dataX="276.00" dataY="32.50" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_3_0">Perfil</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
        	  <div id="mi-2226dae0-Path_386" class="path firer commentable non-processed" customid="User"   datasizewidth="16.00px" datasizeheight="16.00px" dataX="280.00" dataY="14.00"  >\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	      	<?xml version="1.0" encoding="UTF-8"?>\
        	      	<svg xmlns="http://www.w3.org/2000/svg" width="16.0" height="16.0" viewBox="280.0 603.0 16.0 16.0" preserveAspectRatio="none">\
        	      	  <g>\
        	      	    <defs>\
        	      	      <path id="mi-2226dae0-Path_386-11a5b" d="M288.0 611.0 C290.210000038147 611.0 292.0 609.210000038147 292.0 607.0 C292.0 604.789999961853 290.210000038147 603.0 288.0 603.0 C285.789999961853 603.0 284.0 604.789999961853 284.0 607.0 C284.0 609.210000038147 285.789999961853 611.0 288.0 611.0 Z M288.0 613.0 C285.32999992370605 613.0 280.0 614.3400000333786 280.0 617.0 L280.0 619.0 L296.0 619.0 L296.0 617.0 C296.0 614.3399999141693 290.67000007629395 613.0 288.0 613.0 Z "></path>\
        	      	    </defs>\
        	      	    <g style="mix-blend-mode:normal">\
        	      	      <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#mi-2226dae0-Path_386-11a5b" fill="#D8F3DC" fill-opacity="1.0"></use>\
        	      	    </g>\
        	      	  </g>\
        	      	</svg>\
\
        	      </div>\
        	    </div>\
        	  </div>\
        	</div>\
\
\
        	<div id="mi-2226dae0-Group_3" class="group firer ie-background commentable non-processed" customid="Group 3" datasizewidth="0.00px" datasizeheight="0.00px" dataX="155.50" dataY="12.50" >\
        	  <div id="mi-2226dae0-Text_2" class="richtext manualfit firer ie-background commentable non-processed" customid="Actividades"   datasizewidth="50.00px" datasizeheight="11.00px" dataX="155.50" dataY="33.00" >\
        	    <div class="backgroundLayer">\
        	      <div class="colorLayer"></div>\
        	      <div class="imageLayer"></div>\
        	    </div>\
        	    <div class="borderLayer">\
        	      <div class="paddingLayer">\
        	        <div class="content">\
        	          <div class="valign">\
        	            <span id="rtr-mi-2226dae0-Text_2_0">Actividades</span>\
        	          </div>\
        	        </div>\
        	      </div>\
        	    </div>\
        	  </div>\
\
        	  <div id="mi-2226dae0-Image_1" class="image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="21.00px" datasizeheight="21.00px" dataX="170.00" dataY="12.50"   alt="image">\
        	    <div class="borderLayer">\
        	    	<div class="imageViewport">\
        	    		<img src="./images/27f23876-c680-4905-a78b-2d7b446306c4.png" />\
        	    	</div>\
        	    </div>\
        	  </div>\
\
        	</div>\
\
        	<div id="mi-2226dae0-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="60.00px" datasizeheight="36.00px" dataX="151.00" dataY="8.00"  >\
        	  <div class="clickableSpot"></div>\
        	</div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
    <div id="s-db7fe671-828e-474f-9cf4-e0b42d825214" class="screen growth-vertical devMobile devAndroid android-device canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Actividades_futbol"width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./review/screens/db7fe671-828e-474f-9cf4-e0b42d825214/style-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/db7fe671-828e-474f-9cf4-e0b42d825214/fonts-1732892862020.css" />\
      <link type="text/css" rel="stylesheet" href="./review/screens/db7fe671-828e-474f-9cf4-e0b42d825214/custom-device-1732892862020.css" />\
      <div class="freeLayout">\
      <div id="s-Text_1" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_1"   datasizewidth="195.00px" datasizeheight="45.00px" dataX="24.00" dataY="58.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_1_0">Buscar actividades</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_3" class="image firer ie-background commentable non-processed" customid="Image_3"   datasizewidth="333.00px" datasizeheight="113.00px" dataX="17.00" dataY="178.00"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/74edd455-a90d-4f24-8e87-b3c75c17cfc1.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Text_4" class="richtext manualfit firer ie-background commentable non-processed" customid="Text_4"   datasizewidth="99.00px" datasizeheight="47.00px" dataX="25.00" dataY="202.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Text_4_0">F&uacute;tbol</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Button_2" class="button multiline manualfit firer commentable non-processed" customid="Button_2"   datasizewidth="88.00px" datasizeheight="27.00px" dataX="21.00" dataY="248.00" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_2_0">Detalles</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot_5"   datasizewidth="189.00px" datasizeheight="640.00px" dataX="2.00" dataY="0.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Input_text_1" class="text firer focusin click ie-background commentable non-processed" customid="Input_1"  datasizewidth="259.00px" datasizeheight="48.00px" dataX="23.00" dataY="105.00" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="f" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Rectangle_7" class="rectangle manualfit firer commentable non-processed" customid="Rectangle 8"   datasizewidth="49.00px" datasizeheight="49.00px" datasizewidthpx="48.99999999999932" datasizeheightpx="49.0" dataX="302.00" dataY="104.50" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_7_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="image firer ie-background commentable non-processed" customid="Image 5"   datasizewidth="49.00px" datasizeheight="49.00px" dataX="302.00" dataY="104.50"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3e0f8a33-8e73-4f97-a0b2-ef95c0dd8a8d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="49.00px" datasizeheight="49.00px" dataX="302.00" dataY="105.00"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_1" class="imagemap firer swiperight ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="55.00px" datasizeheight="539.00px" dataX="-31.00" dataY="49.88"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer swipeleft ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="66.00px" datasizeheight="435.00px" dataX="326.50" dataY="154.50"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;