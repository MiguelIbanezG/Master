(function(window, undefined) {

  var jimLinks = {
    "572d166d-3b15-463c-b162-7c9de2b8b539" : {
      "Button_1" : [
        "c61d14aa-8516-461e-99ae-5da368ef911e"
      ],
      "Hotspot_5" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Rectangle_29" : [
        "eaff9538-c05c-4f16-8766-42cee8097fe7"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "c788b950-cbd3-4705-bf3a-53d3321caabf" : {
      "Button_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Button_2" : [
        "8f17b440-8828-4207-a253-a72e914aca97"
      ],
      "Hotspot_5" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Rectangle_29" : [
        "eaff9538-c05c-4f16-8766-42cee8097fe7"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "135922a7-1eb2-4537-8d9b-f6e868d13b4b" : {
      "Hotspot_4" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Button_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Hotspot_7" : [
        "38a121bc-d3fa-4507-9ab5-ab5e509e10e9"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "db7fe671-828e-474f-9cf4-e0b42d825214" : {
      "Hotspot_5" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Input_text_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Hotspot_4" : [
        "135922a7-1eb2-4537-8d9b-f6e868d13b4b"
      ]
    },
    "c61d14aa-8516-461e-99ae-5da368ef911e" : {
      "Button_1" : [
        "c788b950-cbd3-4705-bf3a-53d3321caabf"
      ],
      "Button_2" : [
        "c788b950-cbd3-4705-bf3a-53d3321caabf"
      ],
      "Button_3" : [
        "c788b950-cbd3-4705-bf3a-53d3321caabf"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "5166bae2-4a6c-441a-a8c3-5aec9aa58739" : {
      "Input_text_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Hotspot_4" : [
        "135922a7-1eb2-4537-8d9b-f6e868d13b4b"
      ]
    },
    "812e37a9-43d0-4195-8737-a7207c8b01e6" : {
      "Button_2" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_1" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_2" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "eaff9538-c05c-4f16-8766-42cee8097fe7" : {
      "Button_1" : [
        "8f17b440-8828-4207-a253-a72e914aca97"
      ]
    },
    "8f17b440-8828-4207-a253-a72e914aca97" : {
      "Button_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "fb5ee259-0987-49d9-bf14-b1c5a81741e8" : {
      "Input_1" : [
        "db7fe671-828e-474f-9cf4-e0b42d825214",
        "5166bae2-4a6c-441a-a8c3-5aec9aa58739"
      ],
      "Button_1" : [
        "38a121bc-d3fa-4507-9ab5-ab5e509e10e9"
      ],
      "Rectangle_29" : [
        "eaff9538-c05c-4f16-8766-42cee8097fe7"
      ],
      "Hotspot_5" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Hotspot_6" : [
        "135922a7-1eb2-4537-8d9b-f6e868d13b4b"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_2" : [
        "572d166d-3b15-463c-b162-7c9de2b8b539"
      ]
    },
    "38a121bc-d3fa-4507-9ab5-ab5e509e10e9" : {
      "Button_1" : [
        "572d166d-3b15-463c-b162-7c9de2b8b539"
      ],
      "Hotspot_5" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Input_text_1" : [
        "db7fe671-828e-474f-9cf4-e0b42d825214",
        "38a121bc-d3fa-4507-9ab5-ab5e509e10e9",
        "5166bae2-4a6c-441a-a8c3-5aec9aa58739"
      ],
      "Hotspot_4" : [
        "135922a7-1eb2-4537-8d9b-f6e868d13b4b"
      ]
    },
    "11a5b772-fd90-44b1-a192-02f5b4e781f9" : {
      "Text_1" : [
        "8f17b440-8828-4207-a253-a72e914aca97"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ]
    },
    "f39803f7-df02-4169-93eb-7547fb8c961a" : {
      "Text_1" : [
        "8f17b440-8828-4207-a253-a72e914aca97"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ],
      "Button_1" : [
        "eaff9538-c05c-4f16-8766-42cee8097fe7"
      ]
    },
    "1e000438-07d4-4680-9599-132422ef3aef" : {
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf" : {
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Paragraph_25" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ]
    },
    "49bf4ec5-154e-4d68-b63d-df31a53ce4f8" : {
      "Button_1" : [
        "eaff9538-c05c-4f16-8766-42cee8097fe7"
      ]
    },
    "62d08b3d-3c10-42a4-b03b-c898c7047597" : {
    },
    "c3a5fa41-70da-4c97-bebb-cfe2956ccbec" : {
      "Text_1" : [
        "8f17b440-8828-4207-a253-a72e914aca97"
      ],
      "Path_72" : [
        "812e37a9-43d0-4195-8737-a7207c8b01e6"
      ],
      "Hotspot_1" : [
        "fb5ee259-0987-49d9-bf14-b1c5a81741e8"
      ]
    },
    "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3" : {
    }    
  }

  window.jimLinks = jimLinks;
})(window);