	window.widgets = {
		descriptionMap : widgetDescriptionMap = {},
		rootWidgetMap : widgetRootMap = {}
	};

	widgets.descriptionMap[["mi-f7d81311-Rectangle_58", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Rectangle_58", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Basic slide menu", "mi-f7d81311-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-f7d81311-Path_72", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Path_72", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Home", "mi-f7d81311-Path_72"]; 

	widgets.descriptionMap[["mi-f7d81311-Paragraph_25", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Paragraph_25", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Cell_100", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Cell_100", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_100", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_100", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Image_1", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Image_1", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Paragraph_26", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Paragraph_26", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Cell_101", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Cell_101", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_101", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_101", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Image_3", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Image_3", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Paragraph_29", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Paragraph_29", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Cell_145", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Cell_145", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_102", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_102", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Path_19", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Path_19", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Settings", "mi-f7d81311-Path_19"]; 

	widgets.descriptionMap[["mi-f7d81311-Paragraph_37", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Paragraph_37", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Cell_146", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Cell_146", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_103", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_103", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Image_4", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Image_4", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Paragraph_47", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Paragraph_47", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Cell_147", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Cell_147", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_104", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_104", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_12", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_12", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Side menu", "mi-f7d81311-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f7d81311-Panel_11", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Panel_11", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Basic slide menu", "mi-f7d81311-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-f7d81311-Path_147", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ""; 

			widgets.rootWidgetMap[["mi-f7d81311-Path_147", "572d166d-3b15-463c-b162-7c9de2b8b539"]] = ["Menu", "mi-f7d81311-Path_147"]; 

	widgets.descriptionMap[["mi-c7daef0e-Rectangle_58", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Rectangle_58", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Basic slide menu", "mi-c7daef0e-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-c7daef0e-Path_72", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Path_72", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Home", "mi-c7daef0e-Path_72"]; 

	widgets.descriptionMap[["mi-c7daef0e-Paragraph_25", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Paragraph_25", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Cell_100", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Cell_100", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_100", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_100", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Image_1", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Image_1", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Paragraph_26", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Paragraph_26", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Cell_101", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Cell_101", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_101", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_101", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Image_3", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Image_3", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Paragraph_29", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Paragraph_29", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Cell_145", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Cell_145", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_102", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_102", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Path_19", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Path_19", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Settings", "mi-c7daef0e-Path_19"]; 

	widgets.descriptionMap[["mi-c7daef0e-Paragraph_37", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Paragraph_37", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Cell_146", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Cell_146", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_103", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_103", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Image_2", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Image_2", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Paragraph_47", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Paragraph_47", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Cell_147", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Cell_147", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_104", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_104", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_12", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_12", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Side menu", "mi-c7daef0e-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c7daef0e-Panel_11", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Panel_11", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Basic slide menu", "mi-c7daef0e-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-c7daef0e-Path_147", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ""; 

			widgets.rootWidgetMap[["mi-c7daef0e-Path_147", "c788b950-cbd3-4705-bf3a-53d3321caabf"]] = ["Menu", "mi-c7daef0e-Path_147"]; 

	widgets.descriptionMap[["mi-2d629c72-Rectangle_58", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Rectangle_58", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Basic slide menu", "mi-2d629c72-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-2d629c72-Path_72", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Path_72", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Home", "mi-2d629c72-Path_72"]; 

	widgets.descriptionMap[["mi-2d629c72-Paragraph_25", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Paragraph_25", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Cell_100", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Cell_100", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_100", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_100", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Image_1", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Image_1", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Paragraph_26", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Paragraph_26", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Cell_101", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Cell_101", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_101", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_101", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Image_3", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Image_3", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Paragraph_29", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Paragraph_29", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Cell_145", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Cell_145", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_102", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_102", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Path_19", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Path_19", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Settings", "mi-2d629c72-Path_19"]; 

	widgets.descriptionMap[["mi-2d629c72-Paragraph_37", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Paragraph_37", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Cell_146", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Cell_146", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_103", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_103", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Image_2", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Image_2", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Paragraph_47", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Paragraph_47", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Cell_147", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Cell_147", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_104", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_104", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_12", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_12", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Side menu", "mi-2d629c72-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-2d629c72-Panel_11", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Panel_11", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Basic slide menu", "mi-2d629c72-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-2d629c72-Path_147", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ""; 

			widgets.rootWidgetMap[["mi-2d629c72-Path_147", "135922a7-1eb2-4537-8d9b-f6e868d13b4b"]] = ["Menu", "mi-2d629c72-Path_147"]; 

	widgets.descriptionMap[["s-Input_10", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_10", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Radio", "s-Group_56"]; 

	widgets.descriptionMap[["s-Input_11", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["s-Input_11", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Radio", "s-Group_56"]; 

	widgets.descriptionMap[["s-Radio_1", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["s-Radio_1", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Radio", "s-Group_56"]; 

	widgets.descriptionMap[["mi-c750f64d-Rectangle_58", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Rectangle_58", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Basic slide menu", "mi-c750f64d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-c750f64d-Path_72", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Path_72", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Home", "mi-c750f64d-Path_72"]; 

	widgets.descriptionMap[["mi-c750f64d-Paragraph_25", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Paragraph_25", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Cell_100", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Cell_100", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_100", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_100", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Image_1", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Image_1", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Paragraph_26", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Paragraph_26", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Cell_101", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Cell_101", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_101", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_101", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Image_3", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Image_3", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Paragraph_29", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Paragraph_29", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Cell_145", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Cell_145", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_102", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_102", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Path_19", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Path_19", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Settings", "mi-c750f64d-Path_19"]; 

	widgets.descriptionMap[["mi-c750f64d-Paragraph_37", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Paragraph_37", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Cell_146", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Cell_146", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_103", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_103", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Image_2", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Image_2", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Paragraph_47", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Paragraph_47", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Cell_147", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Cell_147", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_104", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_104", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_12", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_12", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Side menu", "mi-c750f64d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-c750f64d-Panel_11", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Panel_11", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Basic slide menu", "mi-c750f64d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-c750f64d-Path_147", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ""; 

			widgets.rootWidgetMap[["mi-c750f64d-Path_147", "c61d14aa-8516-461e-99ae-5da368ef911e"]] = ["Menu", "mi-c750f64d-Path_147"]; 

	widgets.descriptionMap[["mi-dae1560b-Rectangle_58", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Rectangle_58", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Basic slide menu", "mi-dae1560b-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-dae1560b-Path_72", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Path_72", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Home", "mi-dae1560b-Path_72"]; 

	widgets.descriptionMap[["mi-dae1560b-Paragraph_25", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Paragraph_25", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Cell_100", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Cell_100", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Panel_100", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Panel_100", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Image_2", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Image_2", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Paragraph_26", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Paragraph_26", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Cell_101", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Cell_101", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Panel_101", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Panel_101", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Path_19", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Path_19", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Settings", "mi-dae1560b-Path_19"]; 

	widgets.descriptionMap[["mi-dae1560b-Paragraph_37", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Paragraph_37", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Cell_146", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Cell_146", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Panel_103", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Panel_103", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Panel_12", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Panel_12", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Side menu", "mi-dae1560b-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-dae1560b-Panel_11", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Panel_11", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Basic slide menu", "mi-dae1560b-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-dae1560b-Path_147", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ""; 

			widgets.rootWidgetMap[["mi-dae1560b-Path_147", "812e37a9-43d0-4195-8737-a7207c8b01e6"]] = ["Menu", "mi-dae1560b-Path_147"]; 

	widgets.descriptionMap[["mi-67d8f83d-Rectangle_58", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Rectangle_58", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Basic slide menu", "mi-67d8f83d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-67d8f83d-Path_6", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Path_6", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Menu", "mi-67d8f83d-Path_6"]; 

	widgets.descriptionMap[["mi-67d8f83d-Cell_99", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Cell_99", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_99", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_99", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Path_72", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Path_72", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Home", "mi-67d8f83d-Path_72"]; 

	widgets.descriptionMap[["mi-67d8f83d-Paragraph_25", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Paragraph_25", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Cell_100", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Cell_100", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_100", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_100", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Image_1", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Image_1", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Paragraph_26", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Paragraph_26", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Cell_101", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Cell_101", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_101", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_101", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Path_19", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Path_19", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Settings", "mi-67d8f83d-Path_19"]; 

	widgets.descriptionMap[["mi-67d8f83d-Paragraph_37", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Paragraph_37", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Cell_146", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Cell_146", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_103", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_103", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_12", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_12", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Path_41", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Path_41", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Menu", "mi-67d8f83d-Path_41"]; 

	widgets.descriptionMap[["mi-67d8f83d-Cell_149", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Cell_149", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_107", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_107", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_106", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_106", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Side menu", "mi-67d8f83d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-67d8f83d-Panel_11", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Panel_11", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Basic slide menu", "mi-67d8f83d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-67d8f83d-Path_147", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ""; 

			widgets.rootWidgetMap[["mi-67d8f83d-Path_147", "eaff9538-c05c-4f16-8766-42cee8097fe7"]] = ["Menu", "mi-67d8f83d-Path_147"]; 

	widgets.descriptionMap[["mi-bfc17bee-Rectangle_58", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Rectangle_58", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Basic slide menu", "mi-bfc17bee-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-bfc17bee-Path_72", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Path_72", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Home", "mi-bfc17bee-Path_72"]; 

	widgets.descriptionMap[["mi-bfc17bee-Paragraph_25", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Paragraph_25", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Cell_100", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Cell_100", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_100", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_100", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Image_3", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Image_3", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Paragraph_26", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Paragraph_26", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Cell_101", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Cell_101", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_101", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_101", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Image_4", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Image_4", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Paragraph_29", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Paragraph_29", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Cell_145", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Cell_145", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_102", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_102", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Path_19", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Path_19", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Settings", "mi-bfc17bee-Path_19"]; 

	widgets.descriptionMap[["mi-bfc17bee-Paragraph_37", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Paragraph_37", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Cell_146", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Cell_146", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_103", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_103", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Image_5", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Image_5", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Paragraph_47", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Paragraph_47", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Cell_147", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Cell_147", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_104", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_104", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_12", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_12", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Side menu", "mi-bfc17bee-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-bfc17bee-Panel_11", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Panel_11", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Basic slide menu", "mi-bfc17bee-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-bfc17bee-Path_147", "8f17b440-8828-4207-a253-a72e914aca97"]] = ""; 

			widgets.rootWidgetMap[["mi-bfc17bee-Path_147", "8f17b440-8828-4207-a253-a72e914aca97"]] = ["Menu", "mi-bfc17bee-Path_147"]; 

	widgets.descriptionMap[["mi-f6318d3d-Rectangle_58", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Rectangle_58", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Basic slide menu", "mi-f6318d3d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-f6318d3d-Path_72", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Path_72", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Home", "mi-f6318d3d-Path_72"]; 

	widgets.descriptionMap[["mi-f6318d3d-Paragraph_25", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Paragraph_25", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Cell_100", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Cell_100", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_100", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_100", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Image_1", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Image_1", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Paragraph_26", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Paragraph_26", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Cell_101", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Cell_101", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_101", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_101", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Image_5", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Image_5", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Paragraph_29", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Paragraph_29", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Cell_145", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Cell_145", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_102", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_102", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Path_19", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Path_19", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Settings", "mi-f6318d3d-Path_19"]; 

	widgets.descriptionMap[["mi-f6318d3d-Paragraph_37", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Paragraph_37", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Cell_146", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Cell_146", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_103", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_103", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Image_7", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Image_7", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Paragraph_47", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Paragraph_47", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Cell_147", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Cell_147", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_104", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_104", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_12", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_12", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Side menu", "mi-f6318d3d-Dynamic_Panel_7"]; 

	widgets.descriptionMap[["mi-f6318d3d-Panel_11", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Panel_11", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Basic slide menu", "mi-f6318d3d-Dynamic_Panel_73"]; 

	widgets.descriptionMap[["mi-f6318d3d-Path_147", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ""; 

			widgets.rootWidgetMap[["mi-f6318d3d-Path_147", "fb5ee259-0987-49d9-bf14-b1c5a81741e8"]] = ["Menu", "mi-f6318d3d-Path_147"]; 

	widgets.descriptionMap[["mi-2226dae0-Path_72", "11a5b772-fd90-44b1-a192-02f5b4e781f9"]] = ""; 

			widgets.rootWidgetMap[["mi-2226dae0-Path_72", "11a5b772-fd90-44b1-a192-02f5b4e781f9"]] = ["Home", "mi-2226dae0-Path_72"]; 

	widgets.descriptionMap[["mi-2226dae0-Path_386", "11a5b772-fd90-44b1-a192-02f5b4e781f9"]] = ""; 

			widgets.rootWidgetMap[["mi-2226dae0-Path_386", "11a5b772-fd90-44b1-a192-02f5b4e781f9"]] = ["User", "mi-2226dae0-Path_386"]; 

	widgets.descriptionMap[["mi-6980155e-Path_72", "f39803f7-df02-4169-93eb-7547fb8c961a"]] = ""; 

			widgets.rootWidgetMap[["mi-6980155e-Path_72", "f39803f7-df02-4169-93eb-7547fb8c961a"]] = ["Home", "mi-6980155e-Path_72"]; 

	widgets.descriptionMap[["mi-6980155e-Path_386", "f39803f7-df02-4169-93eb-7547fb8c961a"]] = ""; 

			widgets.rootWidgetMap[["mi-6980155e-Path_386", "f39803f7-df02-4169-93eb-7547fb8c961a"]] = ["User", "mi-6980155e-Path_386"]; 

	widgets.descriptionMap[["Rectangle_58", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_58", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_72", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Path_72", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Home", "Path_72"]; 

	widgets.descriptionMap[["Paragraph_25", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_25", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_100", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Cell_100", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_100", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Panel_100", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Image_1", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Image_1", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Paragraph_26", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_26", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_101", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Cell_101", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_101", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Panel_101", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Path_19", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Path_19", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Settings", "Path_19"]; 

	widgets.descriptionMap[["Paragraph_37", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_37", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_146", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Cell_146", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_103", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Panel_103", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_12", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Panel_12", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_11", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Panel_11", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_147", "1e000438-07d4-4680-9599-132422ef3aef"]] = ""; 

			widgets.rootWidgetMap[["Path_147", "1e000438-07d4-4680-9599-132422ef3aef"]] = ["Menu", "Path_147"]; 

	widgets.descriptionMap[["Rectangle_58", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_58", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_72", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Path_72", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Home", "Path_72"]; 

	widgets.descriptionMap[["Paragraph_25", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_25", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_100", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Cell_100", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_100", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_100", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Image_1", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Image_1", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Paragraph_26", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_26", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_101", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Cell_101", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_101", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_101", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Image_3", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Image_3", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Paragraph_29", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_29", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_145", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Cell_145", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_102", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_102", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Path_19", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Path_19", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Settings", "Path_19"]; 

	widgets.descriptionMap[["Paragraph_37", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_37", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_146", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Cell_146", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_103", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_103", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Image_2", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Image_2", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Paragraph_47", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_47", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_147", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Cell_147", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_104", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_104", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_12", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_12", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_11", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Panel_11", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_147", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ""; 

			widgets.rootWidgetMap[["Path_147", "4cbbb73e-c07c-4b9c-83f2-a2f2baf4b7bf"]] = ["Menu", "Path_147"]; 

	widgets.descriptionMap[["Rectangle_58", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_58", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_6", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Path_6", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Menu", "Path_6"]; 

	widgets.descriptionMap[["Cell_99", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Cell_99", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_99", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_99", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Path_72", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Path_72", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Home", "Path_72"]; 

	widgets.descriptionMap[["Paragraph_25", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_25", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_100", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Cell_100", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_100", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_100", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Image_1", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Image_1", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Paragraph_26", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_26", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_101", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Cell_101", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_101", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_101", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Path_19", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Path_19", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Settings", "Path_19"]; 

	widgets.descriptionMap[["Paragraph_37", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_37", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Cell_146", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Cell_146", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_103", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_103", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_12", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_12", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Path_41", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Path_41", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Menu", "Path_41"]; 

	widgets.descriptionMap[["Cell_149", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Cell_149", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_107", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_107", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_106", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_106", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Side menu", "Dynamic_Panel_7"]; 

	widgets.descriptionMap[["Panel_11", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Panel_11", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Basic slide menu", "Dynamic_Panel_73"]; 

	widgets.descriptionMap[["Path_147", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ""; 

			widgets.rootWidgetMap[["Path_147", "62d08b3d-3c10-42a4-b03b-c898c7047597"]] = ["Menu", "Path_147"]; 

	widgets.descriptionMap[["Path_72", "c3a5fa41-70da-4c97-bebb-cfe2956ccbec"]] = ""; 

			widgets.rootWidgetMap[["Path_72", "c3a5fa41-70da-4c97-bebb-cfe2956ccbec"]] = ["Home", "Path_72"]; 

	widgets.descriptionMap[["Path_386", "c3a5fa41-70da-4c97-bebb-cfe2956ccbec"]] = ""; 

			widgets.rootWidgetMap[["Path_386", "c3a5fa41-70da-4c97-bebb-cfe2956ccbec"]] = ["User", "Path_386"]; 

	widgets.descriptionMap[["Path_42", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_42", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Search", "Path_42"]; 

	widgets.descriptionMap[["Input_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Input_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Mask_1", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Mask_1", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Panel_1", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Panel_1", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Input_6", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Input_6", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_6", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_6", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Arrow back", "Path_6"]; 

	widgets.descriptionMap[["Path_7", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_7", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Rectangle_2", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_2", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_8", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_8", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Rectangle_3", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_3", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_9", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_9", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Rectangle_4", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_4", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_10", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_10", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Rectangle_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Rectangle_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Paragraph_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Paragraph_5", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Path_11", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Path_11", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	widgets.descriptionMap[["Panel_2", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ""; 

			widgets.rootWidgetMap[["Panel_2", "fbc0d0a9-8e3f-4f23-b604-7a7cb4887ec3"]] = ["Advanced search", "Dynamic_Panel_1"]; 

	