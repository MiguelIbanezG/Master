# P1 - Auditoría de datos

Para esta práctica se entregan dos ficheros: 
- **"p1_14_ibañez_platon.ipynb"**: En este fichero se encuentran las explicaciones detalladas de los apartados realizados, así como
el código necesario para obtener todos los resultados. Tras la ejecución de este fichero aparecerán en las celdas correspondientes
todas las gráficas pedidas. Este fichero sirve como Memoria de esta primera práctica.
- **"p1_14_ibañez_platon.py"**: Este fichero contiene esencialmente el mismo código que el archivo anterior, pero organizado para facilitar
su ejecución a través de una terminal usando Python. Tras la ejecución de este fichero, aprecerán las mismas salidas en formato de texto
por terminal, mientras que las gráficas serán guardadas como imágenes en una carpeta llamada "images". Estas gráficas son exactamente las mismas que las que se muestran y comentan en la Memoria (Jupyter Notebook).

**Para la ejecución de ambos archivos, los datos comprimidos se deben encontrar en el mismo direcotrio que el propio ejecutable.**


